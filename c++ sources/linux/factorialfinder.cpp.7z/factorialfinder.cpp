#include <iostream>
using namespace std;

void findfactorial(long long num, long long factorialanswer)
{
	factorialanswer =factorialanswer * num;
	if (num==1)
	{
		cout << factorialanswer << endl;
		return;
	}
	findfactorial (num - 1, factorialanswer);
}

long long main()
{
	long long factorialanswer = 1;
	long long num;
	cout << "insert number to be factored: ";
input:
	cin >> num;
	if num < 1
	{
		goto input
	}
	cin.ignore();
	findfactorial (num, factorialanswer);
	cin.get();
	return 0;
}
